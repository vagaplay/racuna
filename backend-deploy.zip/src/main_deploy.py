import os
import sys
from flask import Flask, send_from_directory, send_file, jsonify, request, session, make_response
from flask_cors import CORS
import sqlite3
from datetime import datetime
import json

# Configurar path
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

# Criar aplicação Flask
app = Flask(__name__, static_folder='../static')

# Configuração de segurança
app.config['SECRET_KEY'] = 'bolt_dashboard_secret_key_production_2024'
app.config['SESSION_COOKIE_SECURE'] = False  # Para desenvolvimento
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'

# Configurar CORS para permitir frontend deployado
CORS(app, 
     origins=['https://cdgrjabz.manus.space', 'https://mavlaxgz.manus.space', 'http://localhost:5173', 'http://127.0.0.1:5173'],
     supports_credentials=True,
     allow_headers=['Content-Type', 'Authorization', 'X-Requested-With'],
     methods=['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
     expose_headers=['Content-Type', 'Authorization'])

@app.before_request
def handle_preflight():
    """Handle CORS preflight requests"""
    if request.method == "OPTIONS":
        response = make_response()
        response.headers.add("Access-Control-Allow-Origin", request.headers.get('Origin', '*'))
        response.headers.add('Access-Control-Allow-Headers', "Content-Type,Authorization,X-Requested-With")
        response.headers.add('Access-Control-Allow-Methods', "GET,PUT,POST,DELETE,OPTIONS")
        response.headers.add('Access-Control-Allow-Credentials', 'true')
        return response

@app.after_request
def after_request(response):
    """Add CORS headers to all responses"""
    origin = request.headers.get('Origin')
    if origin in ['https://cdgrjabz.manus.space', 'https://mavlaxgz.manus.space', 'http://localhost:5173']:
        response.headers.add('Access-Control-Allow-Origin', origin)
        response.headers.add('Access-Control-Allow-Credentials', 'true')
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization,X-Requested-With')
        response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    return response

# Banco de dados
DB_PATH = os.path.join(current_dir, 'bolt_dashboard.db')

def init_db():
    """Inicializar banco de dados"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Tabela de usuários
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            name TEXT,
            is_admin BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Inserir usuário de teste se não existir
    cursor.execute('SELECT COUNT(*) FROM users WHERE email = ?', ('test@test.com',))
    if cursor.fetchone()[0] == 0:
        cursor.execute('''
            INSERT INTO users (email, password, name, is_admin)
            VALUES (?, ?, ?, ?)
        ''', ('test@test.com', '123456', 'Usuário Teste', True))
    
    conn.commit()
    conn.close()

# Inicializar banco
init_db()

# Rotas de API
@app.route('/api/health', methods=['GET'])
def health():
    """Endpoint de saúde"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'version': '1.0.0'
    })

@app.route('/api/auth/login', methods=['POST'])
def login():
    """Endpoint de login"""
    try:
        data = request.get_json()
        email = data.get('email')
        password = data.get('password')
        
        if not email or not password:
            return jsonify({'error': 'Email e senha são obrigatórios'}), 400
        
        # Verificar usuário no banco
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE email = ? AND password = ?', (email, password))
        user = cursor.fetchone()
        conn.close()
        
        if user:
            # Criar sessão
            session['user_id'] = user[0]
            session['user_email'] = user[1]
            
            return jsonify({
                'message': 'Login realizado com sucesso',
                'user': {
                    'id': user[0],
                    'email': user[1],
                    'name': user[3],
                    'is_admin': bool(user[4])
                }
            })
        else:
            return jsonify({'error': 'Credenciais inválidas'}), 401
            
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@app.route('/api/auth/status', methods=['GET'])
def auth_status():
    """Verificar status de autenticação"""
    if 'user_id' in session:
        # Buscar dados do usuário
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],))
        user = cursor.fetchone()
        conn.close()
        
        if user:
            return jsonify({
                'authenticated': True,
                'user': {
                    'id': user[0],
                    'email': user[1],
                    'name': user[3],
                    'is_admin': bool(user[4])
                }
            })
    
    return jsonify({'authenticated': False, 'user': None})

@app.route('/api/auth/logout', methods=['POST'])
def logout():
    """Endpoint de logout"""
    session.clear()
    return jsonify({'message': 'Logout realizado com sucesso'})

@app.route('/api/azure/resources', methods=['GET'])
def azure_resources():
    """Endpoint de recursos Azure (mock para demonstração)"""
    return jsonify([
        {
            'id': '/subscriptions/test/resourceGroups/bolt-rg',
            'name': 'bolt-rg',
            'type': 'Microsoft.Resources/resourceGroups',
            'location': 'eastus',
            'status': 'Active'
        },
        {
            'id': '/subscriptions/test/resourceGroups/test-rg',
            'name': 'test-rg', 
            'type': 'Microsoft.Resources/resourceGroups',
            'location': 'westus2',
            'status': 'Active'
        }
    ])

@app.route('/api/azure/costs', methods=['GET'])
def azure_costs():
    """Endpoint de custos Azure (mock para demonstração)"""
    return jsonify({
        'total_cost': 0.00,
        'currency': 'USD',
        'billing_period': datetime.now().strftime('%Y-%m'),
        'daily_costs': [
            {'date': '2024-01-01', 'cost': 0.00},
            {'date': '2024-01-02', 'cost': 0.00}
        ],
        'message': 'Conta Azure vazia - sem custos'
    })

# Servir frontend
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve_frontend(path):
    """Servir arquivos do frontend"""
    if path and os.path.exists(os.path.join(app.static_folder, path)):
        return send_from_directory(app.static_folder, path)
    else:
        return send_from_directory(app.static_folder, 'index.html')

if __name__ == '__main__':
    print("🚀 BOLT Dashboard Backend - Versão Deploy")
    print("✅ Banco de dados inicializado")
    print("✅ CORS configurado para frontend deployado")
    print("✅ Usuário teste: test@test.com / 123456")
    print("🌐 Servidor iniciando...")
    
    app.run(
        host='0.0.0.0',
        port=int(os.environ.get('PORT', 5000)),
        debug=False
    )

