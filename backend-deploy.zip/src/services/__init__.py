"""
Serviços para integração com Azure
"""

